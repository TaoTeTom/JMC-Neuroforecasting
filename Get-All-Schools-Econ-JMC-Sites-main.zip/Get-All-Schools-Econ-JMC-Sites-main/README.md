# Get-All-Schools-Econ-JMC-Sites
Gets the urls for Econ Job Market Website postings.

Uses Selenium to take list of school names and auto gathers jmc pages
